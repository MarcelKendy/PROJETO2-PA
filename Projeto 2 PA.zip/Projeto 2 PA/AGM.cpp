#include <stdio.h>
#include <vector>
#include <algorithm>

using namespace std;

vector < pair <float, pair <int, int> > > grafo, arvore;
int N, E;

int raiz(int n, int *parent) {
    while( n != parent[n] ) {
        n = parent[n];
    }
    return n;
}

int kruskal() {
    int total = 0;    
    int parent[100];
    
    for( int i=0; i<N; i++ ) {
        parent[i] = i;
    }
    
    sort( grafo.begin(), grafo.end() ); //O(n log n)
   
    for( int i=0; i<grafo.size(); i++ ) {
        
        int ru = raiz( grafo[i].second.first, parent );
        int rv = raiz( grafo[i].second.second, parent );
        
        if( ru != rv ) {
            arvore.push_back( grafo[i] );
            parent[ru] = parent[rv];
            total += grafo[i].first;
        }        
    }
	    
    return total;
}

int prim(int start) {
    int total = 0;
    
    bool intree[100];
    for( int i=0; i<N; i++ ) {
        intree[i] = false;
    }
    
    int n = start;
    while( !intree[n] ) {
        intree[n] = true;
    
        int w = 1000000;
        int min = -1;
        int min_next;
        for( int i=0; i<grafo.size(); i++ ) {
            if( grafo[i].second.first == n || grafo[i].second.second == n ) { 
                int next;
                if( grafo[i].second.first == n ) next = grafo[i].second.second;
                else next = grafo[i].second.first;
                
                if( !intree[next] && grafo[i].first<w ) {
                    w = grafo[i].first;
                    min =  i;
                    min_next = next;
                }
            }
        }
        
        if( min != -1 ) {
            n = min_next;
            arvore.push_back( grafo[min] );
            total += grafo[min].first;
        }
    }
    
    return total;    
}

int main()
{
    FILE *fp = fopen("dados.txt", "r");
    
    fscanf(fp, "%d %d\n", &N, &E);
    
    for(int i=0; i<E; i++) {
        int u, v;
        float w;
        fscanf(fp, "%d %d %f\n", &u, &v, &w);        
        grafo.push_back( make_pair(w, make_pair(u-'A',v-'A') ) );
        printf("%d %d %f\n", u, v, w);
    }
    
    int total;
	
	total = kruskal();
	
    for( int i=0; i<arvore.size(); i++ ) {
        printf("%d %d %f\n", arvore[i].second.first+'A', arvore[i].second.second+'A', arvore[i].first );
    }
    printf("Custo total com Kruskal: %i\n\n", total );
    
    arvore.clear();

    total = prim(0);
    
    for( int i=0; i<arvore.size(); i++ ) {
        printf("%d %d %f\n", arvore[i].second.first+'A', arvore[i].second.second+'A', arvore[i].first );
    }
    
    printf("Custo total com Prim: %i\n", total );

    return 0;
}
